import argparse
from pyAudioAnalysis import audioTrainTest as aT

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input_folder',  required=True)
    parser.add_argument('--model_folder',  required=True)
    args = parser.parse_args()
    aT.feature_and_train([args.input_folder], 1.0, 1.0, aT.shortTermWindow, aT.shortTermStep,
                         'svm', args.model_folder, False)
